locations=[
    {
        'id':1, 'name':'Farm','min':10,'max':20
    },
        {
        'id':2, 'name':'Cave','min':5,'max':10
    },
        {
        'id':3, 'name':'House','min':2,'max':5
    },
        {
        'id':4, 'name':'Casino','min':-50,'max':50
    }
]